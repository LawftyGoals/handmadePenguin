The files in this directory go in the "handmade/code" directory
for Day 014 of Handmade Hero. In particular, it _will not compile_
without the handmade.h and handmade.cpp files from the Day 014 source.

They correspond to Chapter 14 of the Handmade Penguin tutorial at
https://davidgow.net/handmadepenguin/ch14.html

It will compile with:
./build.sh
and deposit a ./handmadehero binary in the ../../build/ directory.

If you're looking for the version using the SDL_QueueAudio() function, it can
be found in Day 012's code dump.

Don't bug Casey about this code, the bugs in it are David Gow's
fault, and should be reported to <david@ingeniumdigital.com> or posted in the 
discussion thread on the forums:
https://forums.handmadehero.org/index.php/forum?view=topic&catid=4&id=14

Enjoy,
— David
