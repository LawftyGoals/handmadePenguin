The files in this directory go in the "handmade/code" directory
for Day 007 of Hero, Handmade Hero.

They correspond to Chapter 7 of the Handmade Penguin tutorial at
http://davidgow.net/handmadepenguin/ch7.html

Don't bug Casey about this code, the bugs in it are David Gow's
fault, and should be reported to <david@ingeniumdigital.com>

Enjoy,
— David
