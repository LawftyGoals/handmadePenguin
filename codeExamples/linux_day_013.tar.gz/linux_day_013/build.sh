#!/bin/bash
mkdir -p ../../build
pushd ../../build
c++ -DHANDMADE_SDL=1 ../handmade/code/sdl_handmade.cpp -o handmadehero -g `sdl2-config --cflags --libs`
popd

