The files in this directory go in the "handmade/code" directory
for Day 015 of Handmade Hero. In particular, it _will not compile_
without the handmade.h and handmade.cpp files from the Day 015 source.

They correspond to Chapter 15 of the Handmade Penguin tutorial at
https://davidgow.net/handmadepenguin/ch14.html

It will compile with:
./build.sh
and deposit a ./handmadehero binary in the ../../build/ directory.

To try out the mmap() version (available today only!), use
./build-mmap.sh
to compile the sdl_handmade_mmap.cpp file.

Don't bug Casey about this code, the bugs in it are David Gow's
fault, and should be reported to <david@ingeniumdigital.com> or posted in the 
discussion thread on the forums:
https://forums.handmadehero.org/index.php/forum?view=topic&catid=4&id=14

Enjoy,
— David
