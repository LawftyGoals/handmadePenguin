The files in this directory go in the "handmade/code" directory
for Day 004 of Handmade Hero.

They correspond to Chapter 4 of the Handmade Penguin tutorial at
http://davidgow.net/handmadepenguin/ch4.html

Don't bug Casey about this code, the bugs in it are David Gow's
fault, and should be reported to <david@ingeniumdigital.com>

Enjoy,
— David
