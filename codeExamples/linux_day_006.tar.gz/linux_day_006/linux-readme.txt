The files in this directory go in the "handmade/code" directory
for Day 006 of Handmade Hero.

They correspond to Chapter 6 of the Handmade Penguin tutorial at
http://davidgow.net/handmadepenguin/ch6.html

Don't bug Casey about this code, the bugs in it are David Gow's
fault, and should be reported to <david@ingeniumdigital.com>

Enjoy,
— David
